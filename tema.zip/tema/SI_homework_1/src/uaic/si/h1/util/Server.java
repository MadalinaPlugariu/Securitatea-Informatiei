package uaic.si.h1.util;

import java.io.IOException;
import java.net.ServerSocket;

public abstract class Server {
    private ServerSocket serverSocket;

    public ServerSocket startServer(int port, String serverName){

        try {
            serverSocket = new ServerSocket(port);
            System.out.println(serverName + " has started at port " + port);
        } catch (IOException e) {
            System.out.println(String.format("Unable do open socket at port %", port));
        }

        return serverSocket;
    }

}
