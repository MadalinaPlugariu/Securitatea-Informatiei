package uaic.si.h1.util;

import java.io.IOException;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Random;
import uaic.si.h1.transport.Connection;

/**
 * @author Madalina Plugariu
 * Date : 07.11.2020
 */
public class Utility {

    public static String getRandom(){
        byte[] array = new byte[7]; // length is bounded by 7
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));

        return generatedString;
    }

    public static Connection startConnection(String ip, int port) throws IOException {
        Socket socket = new Socket(ip, port);
        return new Connection(socket);
    }

    public static byte[][] getBlockFromFile(){
        byte[] array = null;
        try {
            array = Files.readAllBytes(Paths.get("file.txt"));

        } catch (IOException e) {
            e.printStackTrace();
        }
        return divideArray(array,16);
    }

    private static byte[][] divideArray(byte[] source, int chunksize) {
        byte[][] ret = new byte[(int) Math.ceil(source.length / (double) chunksize)][chunksize];

        int start = 0;

        for (int i = 0; i < ret.length; i++) {
            if (start + chunksize > source.length) {
                System.arraycopy(source, start, ret[i], 0, source.length - start);
            } else {
                System.arraycopy(source, start, ret[i], 0, chunksize);
            }
            start += chunksize;
        }

        return ret;
    }

}
