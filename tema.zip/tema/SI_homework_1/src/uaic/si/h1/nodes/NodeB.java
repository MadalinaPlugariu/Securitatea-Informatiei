package uaic.si.h1.nodes;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import uaic.si.h1.util.Server;
import uaic.si.h1.transport.Connection;
import uaic.si.h1.util.AES;

public class NodeB extends Server {
    private static String K3 = "K3";
    private AES.Mode mode;
    private Connection connectionNodeA;

    public AES.Mode getMode() {
        return mode;
    }

    public void setMode(AES.Mode mode) {
        this.mode = mode;
    }

    public Connection getConnectionNodeA() {
        return connectionNodeA;
    }

    public NodeB() throws IOException {
        final ServerSocket clientB = startServer(5000, "ClientB");
        System.out.println("Waiting for Client A to connect...");
        final Socket socket = clientB.accept();
        System.out.println("Client A connected");
        this.connectionNodeA = new Connection(socket);
    }

    public static void main(String[] args) throws IOException {
        NodeB nodeB = new NodeB();
        final Connection connectionNodeA = nodeB.getConnectionNodeA();

        final String responseMode = connectionNodeA.receiveMessage();
        System.out.println("Received mode " + responseMode);
        nodeB.setMode(AES.Mode.valueOf(responseMode));

        final String responseKey = connectionNodeA.receiveMessage();
        System.out.println("Received " + responseKey);
        System.out.println("Decrypted response " + AES.decrypt(responseKey, K3, nodeB.getMode()));

        connectionNodeA.sendMessage("OK");

        System.out.println("waiting for chunks size...");
        final int size = Integer.valueOf(connectionNodeA.receiveMessage());
        System.out.println("Chunk size received: " + size);

        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < size; i++) {
            final String chunk = connectionNodeA.receiveMessage();
            stringBuilder.append(AES.decrypt(chunk, responseKey, nodeB.getMode()));
        }
        System.out.println(stringBuilder.toString());

    }

}
