package uaic.si.h1.nodes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import uaic.si.h1.transport.Connection;
import uaic.si.h1.util.AES;
import uaic.si.h1.util.Utility;

public class NodeA {
    private static String K3 = "K3";
    private Connection keyManagerConnection;
    private Connection nodeBConnection;
    private AES.Mode mode;

    public Connection getKeyManagerConnection() {
        return keyManagerConnection;
    }

    public Connection getNodeBConnection() {
        return nodeBConnection;
    }

    public NodeA() throws IOException {
        this.keyManagerConnection = Utility.startConnection("127.0.0.1", 4000);
        this.nodeBConnection = Utility.startConnection("127.0.0.1", 5000);
    }

    public AES.Mode getMode() {
        return mode;
    }

    public void setMode(AES.Mode mode) {
        this.mode = mode;
    }

    public static void main(String[] args) throws IOException {
        NodeA nodeA = new NodeA();
        final Connection keyManagerConnection = nodeA.getKeyManagerConnection();
        final Connection nodeBConnection = nodeA.getNodeBConnection();
        BufferedReader reader =
                new BufferedReader(new InputStreamReader(System.in));

        String inputMode = "";
        while (!inputMode.equals("exit")) {
            System.out.println("Please enter the encrypt mode:");
            inputMode = reader.readLine();

            if (inputMode.equals(AES.Mode.EBC.name()) || inputMode.equals(AES.Mode.CFB.name())) {
                nodeA.setMode(AES.Mode.valueOf(inputMode));
            }else{
                continue;
            }

            keyManagerConnection.sendMessage(inputMode);
            nodeBConnection.sendMessage(inputMode);


            final String raspunsKeye = keyManagerConnection.receiveMessage();
            System.out.println("Response from KeyManager : " + raspunsKeye);
            System.out.println("Decrypted response: " + AES.decrypt(raspunsKeye, K3, nodeA.getMode()));
            nodeBConnection.sendMessage(raspunsKeye);

            final String readyToConnect = nodeBConnection.receiveMessage();
            if (readyToConnect.equals("OK")) {
                System.out.println("Connected with node B. Starting communication...");
                final byte[][] blockFromFile = Utility.getBlockFromFile();
                nodeBConnection.sendMessage(Integer.toString(blockFromFile.length));

                for (int i = 0; i < blockFromFile.length; i++) {
                    final byte[] bytes = blockFromFile[i];
                    final String sendChunk = AES.encrypt(new String(bytes), raspunsKeye, nodeA.getMode());
                    nodeBConnection.sendMessage(sendChunk);
                }

            }

        }

    }

}

