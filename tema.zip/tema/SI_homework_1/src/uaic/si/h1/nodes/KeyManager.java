package uaic.si.h1.nodes;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import uaic.si.h1.util.Server;
import uaic.si.h1.transport.Connection;
import uaic.si.h1.util.AES;
import uaic.si.h1.util.RandomString;

public class KeyManager extends Server {
    private static String K3 = "K3";
    private static String K1 = new RandomString().nextString();
    private static String K2 = new RandomString().nextString();

    private Connection connectionNodeA;

    public KeyManager() throws IOException {
        final ServerSocket start = startServer(4000, "KeyManager");
        System.out.println("Waiting for Client A to connect...");
        Socket socket = start.accept();
        System.out.println("Client A connected");
        this.connectionNodeA = new Connection(socket);
    }

    public Connection getConnectionNodeA() {
        return connectionNodeA;
    }

    public static void main(String[] args) throws IOException {
        KeyManager keyManager = new KeyManager();

        final String msg = keyManager.getConnectionNodeA().receiveMessage();
        if(msg.equals(AES.Mode.EBC.name())){
            String encyptedKeyForA = AES.encrypt(K1, K3, AES.Mode.EBC);
            System.out.println("K1 " + K1);
            keyManager.getConnectionNodeA().sendMessage(encyptedKeyForA);
        }else if(msg.equals("CFB")){
            String encyptedKeyForA = AES.encrypt(K2, K3, AES.Mode.CFB);
            System.out.println("K2 " + K2);
            keyManager.getConnectionNodeA().sendMessage(encyptedKeyForA);
        }
    }

}
